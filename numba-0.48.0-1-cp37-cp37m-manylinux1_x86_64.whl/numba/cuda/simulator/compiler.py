'''
The compiler is not implemented in the simulator. This module provides a stub
to allow tests to import successfully.
'''

compile_kernel = None
